# PLM > 2022-11-13 6:51pm
https://universe.roboflow.com/budapest-university-of-teechnology/plm-d9yui

Provided by a Roboflow user
License: Public Domain

