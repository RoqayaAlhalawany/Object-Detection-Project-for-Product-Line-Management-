# classification > 2022-11-14 6:44pm
https://universe.roboflow.com/budapest-university-of-teechnology-84lcl/classification-2hkao

Provided by a Roboflow user
License: CC BY 4.0

